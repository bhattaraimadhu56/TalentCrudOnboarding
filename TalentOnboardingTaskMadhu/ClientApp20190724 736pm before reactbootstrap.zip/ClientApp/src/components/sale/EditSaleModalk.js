import React, { Component } from "react";
import { Form } from "react-bootstrap";
import { Button, Header, Modal, Input, Segment } from "semantic-ui-react";
import axios from "axios";
import Snackbar from "@material-ui/core/Snackbar";
export class EditSaleModalk extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cus: [],
      prod: [],
      stor: [],
      open: false,
      snackbarOpen: false,
      snackbarMsg: ""
    };
  }
  componentDidMount() {
    fetch("https://localhost:5001/customer/getallcustomers")
      .then(response => response.json())
      .then(data => {
        this.setState({ cus: data });
      });
    fetch("https://localhost:5001/product/getallproducts")
      .then(response => response.json())
      .then(data => {
        this.setState({ prod: data });
      });
    fetch("https://localhost:5001/store/getallstores")
      .then(response => response.json())
      .then(data => {
        this.setState({ stor: data });
      });
  }
  open = () => this.setState({ open: true });
  close = () => this.setState({ open: false });
  snackbarClose = () => {
    this.setState({ snackbarOpen: false });
  };
  handleSubmit = event => {
    event.preventDefault();
    //alert(event.target.salName.value);
    axios({
      method: "PUT",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      params: {
        id: event.target.salId.value,
        productId: event.target.selectProduct.value,
        customerId: event.target.selectCustomer.value,
        storeId: event.target.selectStore.value,
        dateSold: event.target.selectDate.value
      },
      url: "https://localhost:5001/sale/EditSales"
    })
      .then(res => res.json)
      .then(result =>
        // console.log("Sale Updated"),
        this.setState({
          open: false,
          snackbarOpen: true,
          snackbarMsg: "Sale Updated Successfully"
          //snackbarMsg: { result }
        })
      )
      .catch(err => {
        console.error("Fail to Update Sale");
      });
    this.setState({ open: false });
  };

  render() {
    const { open } = this.state;
    return (
      <div>
        <Snackbar
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
          open={this.state.snackbarOpen}
          autoHideDuration={1500}
          onClose={this.snackbarClose}
          message={<span id="message-id">{this.state.snackbarMsg}</span>}
        />
        <Modal
          open={open}
          onOpen={this.open}
          onClose={this.close}
          size="small"
          trigger={<Button icon="edit" content="Edit" primary />}
          closeIcon
        >
          <Header icon="vcard" content="Edit Sale" />
          <Modal.Content>
            <Form onSubmit={this.handleSubmit}>
              <Form.Group controlId="Department">
                <Form.Label>Product</Form.Label>

                <Form.Control as="select" defaultValue={this.props.productName}>
                  {this.state.prod.map(dep => (
                    <option key={dep.id}>{dep.productName}</option>
                  ))}
                </Form.Control>
              </Form.Group>
            </Form>
          </Modal.Content>
        </Modal>
      </div>
    );
  }
}
